from drain3.template_miner import TemplateMiner

